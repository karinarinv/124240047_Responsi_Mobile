import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../models/anime_model.dart';
import '../controllers/library_controller.dart';
import '../services/api_service.dart';

class DetailPage extends StatefulWidget {
  final String animeId;

  const DetailPage({super.key, required this.animeId});

  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  late Future<Anime> _animeFuture;
  final LibraryController _libraryController = Get.find<LibraryController>();
  final Color themeColor = const Color(0xFFFF5722);

  @override
  void initState() {
    super.initState();
    _animeFuture = ApiService.fetchAnimesDetail(widget.animeId);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        title: const Text(
          'Detail',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
            fontSize: 18,
          ),
        ),
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        // b. User dapat kembali ke Home dari Detail Page
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Get.back(),
        ),
      ),
      // c. Ada loading indicator untuk saat load data detail anime
      body: FutureBuilder<Anime>(
        future: _animeFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(color: themeColor),
            );
          }

          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.error_outline, size: 48, color: Colors.red),
                    const SizedBox(height: 12),
                    Text(
                      'Gagal memuat detail anime:\n${snapshot.error}',
                      style: TextStyle(color: Colors.grey.shade300),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: themeColor),
                      onPressed: () {
                        setState(() {
                          _animeFuture =
                              ApiService.fetchAnimesDetail(widget.animeId);
                        });
                      },
                      child: const Text('Coba Lagi',
                          style: TextStyle(color: Colors.white)),
                    ),
                  ],
                ),
              ),
            );
          }

          final anime = snapshot.data;
          if (anime == null) {
            return const Center(
              child: Text(
                'Data anime tidak ditemukan',
                style: TextStyle(color: Colors.white),
              ),
            );
          }

          // i. Cover Image, sebagai hero image (fallback ke poster image jika kosong)
          final coverImageUrl = anime.coverImage.isNotEmpty
              ? anime.coverImage
              : anime.posterImage;

          return SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Hero Cover Image
                coverImageUrl.isNotEmpty
                    ? Image.network(
                        coverImageUrl,
                        width: double.infinity,
                        height: 240,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) => Container(
                          height: 240,
                          color: const Color(0xFF1E1E1E),
                          child: const Center(
                            child: Icon(Icons.broken_image,
                                size: 60, color: Colors.grey),
                          ),
                        ),
                      )
                    : Container(
                        height: 240,
                        color: const Color(0xFF1E1E1E),
                        child: const Center(
                          child: Icon(Icons.movie, size: 60, color: Colors.grey),
                        ),
                      ),

                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Judul Anime
                      Text(
                        anime.title,
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 8),

                      // ii. Rating (averageRating)
                      Row(
                        children: [
                          const Icon(Icons.star_rounded,
                              color: Color(0xFFFFC107), size: 20),
                          const SizedBox(width: 6),
                          Text(
                            anime.averageRating,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),

                      // iii. Rating Umur & Jumlah Episode
                      Text(
                        "${anime.ageRating} • ${anime.episodeCount != null ? '${anime.episodeCount} Episodes' : 'N/A Episodes'}",
                        style: TextStyle(
                          color: Colors.grey.shade400,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 20),

                      // v. Button "Nonton" (statis) & vi. Button Tambah Favorit
                      Row(
                        children: [
                          // Button Nonton (bersifat static)
                          Expanded(
                            child: SizedBox(
                              height: 48,
                              child: ElevatedButton.icon(
                                onPressed: () {
                                  Get.snackbar(
                                    'Nonton',
                                    'Fitur nonton ${anime.title} bersifat statis.',
                                    snackPosition: SnackPosition.BOTTOM,
                                    backgroundColor: const Color(0xFF282828),
                                    colorText: Colors.white,
                                    margin: const EdgeInsets.all(12),
                                    duration: const Duration(seconds: 2),
                                  );
                                },
                                icon: const Icon(
                                  Icons.play_arrow_rounded,
                                  color: Colors.white,
                                ),
                                label: const Text(
                                  'Nonton',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                  ),
                                ),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: themeColor,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  elevation: 3,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),

                          // vi. Button Favorit (UI berbeda jika difavoritkan)
                          Obx(() {
                            final isFavorite =
                                _libraryController.isOwned(anime.id);
                            return Container(
                              height: 48,
                              width: 48,
                              decoration: BoxDecoration(
                                color: const Color(0xFF1E1E1E),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: isFavorite
                                      ? Colors.red
                                      : Colors.grey.shade700,
                                  width: 1.2,
                                ),
                              ),
                              child: IconButton(
                                icon: Icon(
                                  isFavorite
                                      ? Icons.favorite
                                      : Icons.favorite_border,
                                  color: isFavorite ? Colors.red : Colors.white,
                                  size: 22,
                                ),
                                onPressed: () {
                                  _libraryController.toggleAnime(anime);
                                },
                              ),
                            );
                          }),
                        ],
                      ),
                      const SizedBox(height: 24),

                      // iv. Sinopsis Anime
                      const Text(
                        'Overview',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        (anime.synopsis != null && anime.synopsis!.isNotEmpty)
                            ? anime.synopsis!
                            : 'Tidak ada sinopsis tersedia.',
                        style: TextStyle(
                          color: Colors.grey.shade300,
                          fontSize: 14,
                          height: 1.5,
                        ),
                      ),
                      const SizedBox(height: 30),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
