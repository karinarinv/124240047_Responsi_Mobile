import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/library_controller.dart';
import 'detail_page.dart';

class FavoritePage extends StatelessWidget {
  const FavoritePage({super.key});

  @override
  Widget build(BuildContext context) {
    final LibraryController controller = Get.find<LibraryController>();

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        title: const Text(
          'Daftar Favorit',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
            fontSize: 20,
          ),
        ),
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: false,
      ),
      body: Obx(() {
        final list = controller.animes.toList();

        if (list.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.favorite_border_rounded,
                  size: 64,
                  color: Colors.grey.shade600,
                ),
                const SizedBox(height: 16),
                Text(
                  'Daftar favorit masih kosong.',
                  style: TextStyle(color: Colors.grey.shade400, fontSize: 16),
                ),
                const SizedBox(height: 6),
                Text(
                  'Tambahkan anime favorit Anda dari halaman Beranda!',
                  style: TextStyle(color: Colors.grey.shade600, fontSize: 13),
                ),
              ],
            ),
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          itemCount: list.length,
          itemBuilder: (context, index) {
            final anime = list[index];

            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                color: const Color(0xFF1E1E1E),
                borderRadius: BorderRadius.circular(10),
              ),
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 6,
                ),
                // b. Ketika anime diklik, menuju Detail Page
                onTap: () {
                  Get.to(() => DetailPage(animeId: anime.id))?.then((_) {
                    controller.loadAnimes();
                  });
                },
                // i. Poster Image
                leading: ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: anime.posterImage.isNotEmpty
                      ? Image.network(
                          anime.posterImage,
                          width: 50,
                          height: 60,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) =>
                              Container(
                            width: 50,
                            height: 60,
                            color: const Color(0xFF282828),
                            child: const Icon(
                              Icons.broken_image,
                              color: Colors.grey,
                            ),
                          ),
                        )
                      : Container(
                          width: 50,
                          height: 60,
                          color: const Color(0xFF282828),
                          child: const Icon(
                            Icons.movie,
                            color: Colors.grey,
                          ),
                        ),
                ),
                // i. Nama Anime
                title: Text(
                  anime.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                  ),
                ),
                // i. Rating
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 4.0),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.star_rounded,
                        color: Color(0xFFFFC107),
                        size: 16,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        anime.averageRating,
                        style: TextStyle(
                          color: Colors.grey.shade400,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
                // ii. Tombol delete untuk menghapus anime dari library/favorit
                trailing: IconButton(
                  icon: const Icon(Icons.delete_rounded, color: Colors.red),
                  onPressed: () {
                    controller.removeAnime(anime.id, anime.title);
                  },
                ),
              ),
            );
          },
        );
      }),
    );
  }
}

// Alias agar kompatibel jika di-import sebagai LibraryPage
typedef LibraryPage = FavoritePage;
