import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../models/anime_model.dart';
import '../services/api_service.dart';
import 'detail_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Anime> _allAnimes = [];
  bool _isLoading = true;
  String? _errorMessage;
  final Color themeColor = const Color(0xFFFF5722);

  @override
  void initState() {
    super.initState();
    _fetchAnimes();
  }

  void _fetchAnimes() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final animes = await ApiService.fetchAnimes();
      setState(() {
        _allAnimes = animes;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        titleSpacing: 16,
        title: Row(
          children: [
            Container(
              width: 22,
              height: 22,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: themeColor, width: 2.5),
              ),
              child: Center(
                child: Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    color: themeColor,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              'Keripikroll',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: themeColor,
                fontSize: 20,
              ),
            ),
          ],
        ),
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: false,
      ),
      body: RefreshIndicator(
        color: themeColor,
        backgroundColor: const Color(0xFF1E1E1E),
        onRefresh: () async => _fetchAnimes(),
        child: _buildContent(),
      ),
    );
  }

  Widget _buildContent() {
    // 1. Loading Indicator (Kriteria 2.c)
    if (_isLoading) {
      return Center(
        child: CircularProgressIndicator(color: themeColor),
      );
    }

    // 2. Error State
    if (_errorMessage != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, size: 48, color: Colors.red),
              const SizedBox(height: 12),
              Text(
                'Gagal memuat anime:\n$_errorMessage',
                style: TextStyle(color: Colors.grey.shade300, fontSize: 14),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: themeColor),
                onPressed: _fetchAnimes,
                child: const Text(
                  'Coba Lagi',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      );
    }

    // 3. GridView Daftar Anime (Kriteria 2.b)
    return GridView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.58,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: _allAnimes.length,
      itemBuilder: (context, index) {
        final anime = _allAnimes[index];

        return GestureDetector(
          onTap: () {
            // Navigasi ke DetailPage
            Get.to(() => DetailPage(animeId: anime.id));
          },
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.3),
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            clipBehavior: Clip.antiAlias,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // i. Poster Image
                Expanded(
                  child: anime.posterImage.isNotEmpty
                      ? Image.network(
                          anime.posterImage,
                          width: double.infinity,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) =>
                              Container(
                            color: const Color(0xFF282828),
                            child: const Center(
                              child: Icon(
                                Icons.broken_image,
                                color: Colors.grey,
                              ),
                            ),
                          ),
                        )
                      : Container(
                          color: const Color(0xFF282828),
                          child: const Center(
                            child: Icon(
                              Icons.movie,
                              color: Colors.grey,
                            ),
                          ),
                        ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10.0,
                    vertical: 8.0,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ii. Nama Anime (titles -> en_jp)
                      Text(
                        anime.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 2),

                      // iii. Rating Umur & Jumlah Episode
                      Text(
                        "${anime.ageRating} • ${anime.episodeCount != null ? '${anime.episodeCount} Episodes' : 'N/A Episodes'}",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: Colors.grey.shade400,
                          fontSize: 11,
                        ),
                      ),
                      const SizedBox(height: 4),

                      // iv. Rating (averageRating)
                      Row(
                        children: [
                          const Icon(
                            Icons.star_rounded,
                            color: Color(0xFFFFC107),
                            size: 16,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            anime.averageRating,
                            style: TextStyle(
                              color: Colors.grey.shade300,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
