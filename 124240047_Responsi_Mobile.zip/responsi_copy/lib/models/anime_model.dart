class Anime {
  final String id;
  final String title;
  final String averageRating;
  final String? synopsis;
  final String ageRating;
  final String posterImage;
  final String coverImage;
  final String? episodeCount;

  Anime({
    required this.id,
    required this.title,
    required this.averageRating,
    this.synopsis,
    required this.ageRating,
    required this.posterImage,
    required this.coverImage,
    this.episodeCount,
  });

  /// Factory untuk mem-parse JSON dari Kitsu API
  /// Mendukung format item dari daftar anime maupun detail anime
  factory Anime.fromJson(Map<String, dynamic> json) {
    // Di Kitsu API, data atribut berada dalam key 'attributes'
    final attributes = (json['attributes'] is Map<String, dynamic>)
        ? json['attributes'] as Map<String, dynamic>
        : json;

    final id = (json['id'] ?? attributes['id'] ?? '').toString();

    // 1. Nama Anime (titles -> en_jp, dengan fallback canonicalTitle/en)
    String animeTitle = '';
    if (attributes['titles'] is Map<String, dynamic>) {
      final titlesMap = attributes['titles'] as Map<String, dynamic>;
      animeTitle = titlesMap['en_jp']?.toString() ??
          titlesMap['en']?.toString() ??
          titlesMap['ja_jp']?.toString() ??
          '';
    }
    if (animeTitle.isEmpty) {
      animeTitle = attributes['canonicalTitle']?.toString() ?? 'Untitled';
    }

    // 2. Rating (averageRating)
    final avgRating = attributes['averageRating']?.toString() ?? '0.0';

    // 3. Rating Umur (ageRating)
    final age = attributes['ageRating']?.toString() ?? 'N/A';

    // 4. Jumlah Episode (episodeCount)
    final epCount = attributes['episodeCount']?.toString();

    // 5. Sinopsis (synopsis)
    final syn = attributes['synopsis']?.toString() ??
        attributes['description']?.toString() ??
        '';

    // 6. Poster Image (posterImage -> small / medium / tiny / original)
    String poster = '';
    if (attributes['posterImage'] is Map<String, dynamic>) {
      final pMap = attributes['posterImage'] as Map<String, dynamic>;
      poster = pMap['small']?.toString() ??
          pMap['medium']?.toString() ??
          pMap['tiny']?.toString() ??
          pMap['original']?.toString() ??
          '';
    }

    // 7. Cover Image (coverImage -> small / large / tiny / original)
    String cover = '';
    if (attributes['coverImage'] is Map<String, dynamic>) {
      final cMap = attributes['coverImage'] as Map<String, dynamic>;
      cover = cMap['small']?.toString() ??
          cMap['large']?.toString() ??
          cMap['tiny']?.toString() ??
          cMap['original']?.toString() ??
          '';
    }
    // Fallback jika anime tidak memiliki coverImage dari API
    if (cover.isEmpty) {
      cover = poster;
    }

    return Anime(
      id: id,
      title: animeTitle,
      averageRating: avgRating,
      synopsis: syn,
      ageRating: age,
      posterImage: poster,
      coverImage: cover,
      episodeCount: epCount,
    );
  }

  /// Serialisasi ke Map untuk disimpan di database lokal Hive
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'averageRating': averageRating,
      'synopsis': synopsis,
      'ageRating': ageRating,
      'posterImage': posterImage,
      'coverImage': coverImage,
      'episodeCount': episodeCount,
    };
  }

  /// Deserialisasi dari Hive Box
  factory Anime.fromMap(Map<dynamic, dynamic> map) {
    return Anime(
      id: (map['id'] ?? '').toString(),
      title: (map['title'] ?? map['titles'] ?? 'Untitled').toString(),
      averageRating: (map['averageRating'] ?? '0.0').toString(),
      synopsis: map['synopsis']?.toString() ?? map['description']?.toString(),
      ageRating: (map['ageRating'] ?? 'N/A').toString(),
      posterImage: (map['posterImage'] ?? map['tinyPosterImage'] ?? map['imageUrl'] ?? '').toString(),
      coverImage: (map['coverImage'] ?? map['posterImage'] ?? '').toString(),
      episodeCount: map['episodeCount']?.toString(),
    );
  }

  // Getter pembantu untuk kompatibilitas
  String get titles => title;
  String get tinyPosterImage => posterImage;
  String? get imageUrl => posterImage;
  String? get description => synopsis;
}
