export 'anime_model.dart';
import 'anime_model.dart';

typedef Show = Anime;
