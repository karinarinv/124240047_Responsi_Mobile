import 'package:shared_preferences/shared_preferences.dart';

class PrefService {
  static const String _keyIsLoggedIn = 'is_logged_in';
  static const String _keyUsername = 'user_username';

  /// Simpan sesi login aktif dan data username ke SharedPreferences
  static Future<void> saveLoginSession(String username) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyIsLoggedIn, true);
    await prefs.setString(_keyUsername, username.trim());
  }

  /// Cek apakah user sedang dalam sesi login
  static Future<bool> isLoggedIn() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_keyIsLoggedIn) ?? false;
  }

  /// Ambil username user untuk Profile Page
  static Future<String> getUsername() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyUsername) ?? 'Bin Kotob';
  }

  /// Alias getEmail untuk kompatibilitas jika dipanggil
  static Future<String> getEmail() async {
    return getUsername();
  }

  /// Logout: hapus sesi login aktif dari SharedPreferences
  static Future<void> clearSession() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyIsLoggedIn);
    await prefs.remove(_keyUsername);
  }
}
