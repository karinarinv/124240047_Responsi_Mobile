import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/anime_model.dart';

class ApiService {
  static const String baseUrl =
      'https://kitsu.io/api/edge/anime?page[limit]=20&page[offset]=0';

  /// 1. Mengambil daftar anime dari Kitsu API
  static Future<List<Anime>> fetchAnimes() async {
    final response = await http.get(Uri.parse(baseUrl));

    if (response.statusCode == 200) {
      final decoded = jsonDecode(response.body) as Map<String, dynamic>;
      final List<dynamic> dataList = decoded['data'] as List<dynamic>? ?? [];

      return dataList
          .map((dynamic item) => Anime.fromJson(item as Map<String, dynamic>))
          .toList();
    } else {
      throw Exception(
          'Gagal memuat daftar Anime (Status: ${response.statusCode})');
    }
  }

  /// 2. Mengambil detail anime berdasarkan anime_id
  static Future<Anime> fetchAnimesDetail(String animeId) async {
    final response =
        await http.get(Uri.parse('https://kitsu.io/api/edge/anime/$animeId'));

    if (response.statusCode == 200) {
      final decoded = jsonDecode(response.body) as Map<String, dynamic>;
      final data = decoded['data'] as Map<String, dynamic>;
      return Anime.fromJson(data);
    } else {
      throw Exception(
          'Gagal memuat detail anime (Status: ${response.statusCode})');
    }
  }
}
