import 'package:hive_flutter/hive_flutter.dart';
import '../models/anime_model.dart';

class LibraryService {
  static const String boxName = 'Keripikroll_favorites_box';

  static Box get _box => Hive.box(boxName);

  /// Menambahkan anime ke Hive
  static Future<void> addAnime(Anime anime) async {
    await _box.put(anime.id, anime.toMap());
  }

  /// Menghapus anime dari Hive berdasarkan ID
  static Future<void> removeAnime(String id) async {
    await _box.delete(id);
  }

  /// Mengecek apakah anime sudah ada di favorit
  static bool isAnimeInLibrary(String id) {
    return _box.containsKey(id);
  }

  /// Mengambil semua anime favorit dari Hive
  static List<Anime> getAllAnimes() {
    final List<Anime> list = [];
    for (var i = 0; i < _box.length; i++) {
      final data = _box.getAt(i);
      if (data != null && data is Map) {
        list.add(Anime.fromMap(data));
      }
    }
    return list;
  }

  /// Mengambil jumlah anime favorit dari Hive
  static int getAnimesCount() {
    return _box.length;
  }
}
