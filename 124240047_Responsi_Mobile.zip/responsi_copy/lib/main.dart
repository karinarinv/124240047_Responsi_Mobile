import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'controllers/library_controller.dart';
import 'services/library_service.dart';
import 'services/pref_service.dart';
import 'views/login_page.dart';
import 'views/main_navigation_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 1. Inisialisasi Database Hive lokal & buka box
  await Hive.initFlutter();
  await Hive.openBox(LibraryService.boxName);

  // 2. Daftarkan Controller GetX ke dependency injection
  Get.put(LibraryController());

  // 3. Cek apakah user sudah pernah login sebelumnya di SharedPreferences
  final bool isLoggedIn = await PrefService.isLoggedIn();

  runApp(MyApp(isLoggedIn: isLoggedIn));
}

class MyApp extends StatelessWidget {
  final bool isLoggedIn;

  const MyApp({super.key, required this.isLoggedIn});

  @override
  Widget build(BuildContext context) {
    // 🎨 Warna tema utama Keripikroll (Orange)
    const Color appPrimaryColor = Color(0xFFFF5722);

    return GetMaterialApp(
      title: 'Keripikroll',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF121212),
        primaryColor: appPrimaryColor,
        colorScheme: const ColorScheme.dark(
          primary: appPrimaryColor,
          surface: Color(0xFF1E1E1E),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF121212),
          elevation: 0,
          titleTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
          iconTheme: IconThemeData(color: Colors.white),
        ),
      ),
      home: isLoggedIn ? const MainNavigationPage() : const LoginPage(),
    );
  }
}
