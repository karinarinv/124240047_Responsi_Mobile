import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../models/anime_model.dart';
import '../services/library_service.dart';

class LibraryController extends GetxController {
  final RxList<Anime> animes = <Anime>[].obs;

  @override
  void onInit() {
    super.onInit();
    loadAnimes();
  }

  /// Memuat semua data favorit dari database lokal Hive
  void loadAnimes() {
    animes.assignAll(LibraryService.getAllAnimes());
  }

  /// Cek apakah anime sudah ada di favorit
  bool isOwned(String id) {
    return animes.any((anime) => anime.id == id);
  }

  bool isFavorite(String id) => isOwned(id);

  /// Toggle tambah/hapus favorit
  Future<void> toggleAnime(Anime anime) async {
    if (isOwned(anime.id)) {
      await LibraryService.removeAnime(anime.id);
      loadAnimes();
      Get.snackbar(
        'Favorit',
        '${anime.title} dihapus dari daftar favorit.',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: const Color(0xFF282828),
        colorText: Colors.white,
        margin: const EdgeInsets.all(12),
        duration: const Duration(seconds: 2),
      );
    } else {
      await LibraryService.addAnime(anime);
      loadAnimes();
      Get.snackbar(
        'Favorit',
        '${anime.title} ditambahkan ke favorit!',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: const Color(0xFFFF5722),
        colorText: Colors.white,
        margin: const EdgeInsets.all(12),
        duration: const Duration(seconds: 2),
      );
    }
  }

  /// Hapus anime dari favorit
  Future<void> removeAnime(String id, String title) async {
    await LibraryService.removeAnime(id);
    loadAnimes();
    Get.snackbar(
      'Dihapus',
      '$title telah dihapus dari daftar favorit.',
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: const Color(0xFF282828),
      colorText: Colors.white,
      margin: const EdgeInsets.all(12),
      duration: const Duration(seconds: 2),
    );
  }
}
