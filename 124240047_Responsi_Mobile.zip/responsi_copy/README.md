# RESPONSI PRAKTIKUM PEMROGRAMAN MOBILE SI-F
## Aplikasi Keripikroll (Kitsu Anime App)

**NIM:** 124240047  
**Kelas:** Praktikum Mobile SI-F  
**Mata Kuliah:** Praktikum Pemrograman Aplikasi Mobile  
**Nama Repository:** `124240047_Responsi_Mobile`

---

## 📱 Deskripsi Aplikasi
**Keripikroll** adalah aplikasi mobile streaming anime berbasis Flutter yang menggunakan data dinamis dari public REST API **Kitsu API** (`https://kitsu.io/api/edge/anime`). Aplikasi ini dibangun dengan tema dark mode beraksen warna oranye khas Keripikroll, dilengkapi autentikasi lokal via SharedPreferences, penyimpanan anime favorit secara offline dengan database lokal Hive, dan state management GetX.

---

## 🛠️ Pemenuhan Kriteria & Soal Responsi

### 1. Login Page (Bobot 10%)
- **Autentikasi Akun User:** Kredensial username dan password bebas dengan form validation & handling jika input salah/kosong.
- **Penyimpanan Sesi:** Informasi sesi login dan username disimpan secara persistent menggunakan **SharedPreferences**.
- **Auto-Login:** Jika user telah login sebelumnya, aplikasi langsung mengarahkan ke halaman utama.

### 2. Home Page (Bobot 25%)
- **BottomNavigationBar:** Navigasi 3 halaman utama: **Beranda (Home)**, **Favorit**, dan **Profil**.
- **GridView Anime:** Menampilkan daftar anime 2 kolom secara dinamis dari API:
  - Poster Image (`posterImage -> small/tiny/medium`)
  - Nama Anime (`titles -> en_jp`)
  - Rating Umur & Jumlah Episode (`ageRating`, `episodeCount`)
  - Rating (`averageRating` dengan ikon bintang)
- **Loading Indicator:** Terdapat indikator loading (`CircularProgressIndicator`) saat data di-fetch.
- **Pemisahan File:** Logika fetch dan parse API dipisahkan pada `lib/services/api_service.dart`.

### 3. Detail Page (Bobot 35%)
- **Navigasi:** Navigasi dari kartu anime di Home ke Detail Page dengan ID spesifik (`https://kitsu.io/api/edge/anime/{anime_id}`).
- **Elemen Wajib Detail:**
  1. Cover Image sebagai hero image (`coverImage -> small/large/posterImage`)
  2. Rating (`averageRating`)
  3. Rating Umur & Jumlah Episode (`ageRating`, `episodeCount`)
  4. Sinopsis Anime (`synopsis`)
  5. Button "Nonton" (bersifat statis)
  6. Button Favorit dengan perubahan UI yang berbeda (ikon hati berubah merah saat difavoritkan).
- **Kembali ke Home:** Tombol Back di AppBar untuk kembali ke halaman sebelumnya.
- **Loading Indicator:** Menampilkan indikator loading saat memuat detail anime.

### 4. Favorite Page (Bobot 20%)
- **Daftar Favorit:** Menampilkan list anime yang telah ditambahkan ke favorit.
  - Poster Image, Nama anime, dan Rating.
  - Tombol delete untuk menghapus anime dari daftar favorit.
- **Navigasi ke Detail:** Klik item list akan membuka Detail Page anime tersebut.
- **Penyimpanan Hive:** Data dikelola secara offline menggunakan database lokal **Hive**.

### 5. Profile Page (Bobot 10%)
- **Data User:**
  - Username diambil langsung dari **SharedPreferences**.
  - Jumlah anime yang disukai dihitung langsung dari data pada **Hive**.
- **Logout:** Menghapus sesi SharedPreferences dan mengarahkan kembali ke halaman Login.

---

## 🌐 Endpoints API yang Digunakan
- **Daftar Semua Anime:**  
  `https://kitsu.io/api/edge/anime/?page[limit]=20&page[offset]=0`
- **Detail Anime:**  
  `https://kitsu.io/api/edge/anime/{anime_id}`
