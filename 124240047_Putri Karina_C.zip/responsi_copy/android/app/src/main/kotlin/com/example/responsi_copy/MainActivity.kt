package com.example.responsi_copy

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
