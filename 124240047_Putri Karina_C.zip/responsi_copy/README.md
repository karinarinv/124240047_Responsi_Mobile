# LATIHAN RESPONSI PRAKTIKUM PEMROGRAMAN MOBILE SI-F
## Aplikasi NontonSkuy! (TV Shows & Series)

**NIM:** 124240047  
**Kelas:** Praktikum Mobile SI-F  
**Nama Repository:** `Latres_Mobile_124240047`

---

## 📱 Deskripsi Aplikasi
**NontonSkuy!** adalah aplikasi mobile berbasis Flutter untuk melihat katalog TV Show dan series dengan data langsung dari public API **TVMaze** (`https://api.tvmaze.com`). Aplikasi ini dilengkapi dengan sistem autentikasi lokal, penyimpanan lokal untuk daftar favorit, manajemen state reaktif, serta antarmuka modern bertema dark mode dengan aksen warna merah khas aplikasi streaming film.

---

## 🛠️ Fitur & Kriteria Pemenuhan Tugas

### 1. Login Page (Bobot 15%)
- Input **Username:** `124240047` (NIM).
- Input **Password:** `123`.
- Validasi input login dengan pesan umpan balik informatif (Snackbar).
- Menyimpan sesi login ke penyimpanan lokal menggunakan **SharedPreferences** (`is_logged_in` dan `username`).
- Fitur auto-login: Jika sesi masih tersimpan saat aplikasi dibuka, langsung masuk ke beranda.
- Logout menghapus sesi SharedPreferences dan mengarahkan kembali ke halaman Login.

### 2. Home Page / Daftar Shows (Bobot 30%)
- Navigasi **BottomNavigationBar** untuk berpindah antar halaman: **Beranda**, **Favorit**, dan **Profil**.
- Data diambil secara realtime dari REST API TVMaze: `https://api.tvmaze.com/shows`.
- Tampilan dalam bentuk **Grid 2 kolom** yang rapi dan elegan:
  1. Poster Gambar (dengan loading indicator & penanganan error)
  2. Judul TV Show
  3. Rating (disertai ikon bintang emas)
- Terdapat **Loading Indicator** (`CircularProgressIndicator`) saat data sedang di-fetch.
- **Pemisahan Logika:** Mekanisme fetch dan parse data API dipisahkan dari UI ke dalam file service tersendiri (`lib/services/api_service.dart`).
- Fitur *Pull-to-refresh* (`RefreshIndicator`) untuk memperbarui daftar data.
- Klik pada item kartu show akan menavigasi ke halaman **Detail Page**.

### 3. Detail Page (Bobot 25%)
- Data diambil langsung dari endpoint: `https://api.tvmaze.com/shows/{id}`.
- Menampilkan informasi lengkap TV Show:
  1. Gambar Poster Berukuran Besar (High-Res Banner)
  2. Judul TV Show
  3. Rating
  4. Genre (format teks/kategori)
  5. Summary/Overview (tag HTML dibersihkan sehingga teks tampil rapi dan nyaman dibaca)
  6. Informasi tambahan (Status tayang, tanggal rilis, durasi, dan bahasa)
- Tombol **Nonton** interaktif dan tombol **Favorit** (ikon hati) untuk menambah/menghapus show ke/dari daftar favorit.
- Navigasi kembali ke halaman sebelumnya (tombol *Back* di AppBar).

### 4. Favorite Page (Bobot 20%)
- Menampilkan daftar TV show yang disukai/difavoritkan.
- Disimpan secara lokal dan persisten menggunakan **Hive** (`hive_flutter`).
- Dilengkapi tombol hapus (ikon tempat sampah merah) untuk menghapus show dari favorit.
- Klik pada item favorit akan langsung membuka halaman **Detail Page** show tersebut.
- Reaktif secara instan berkat integrasi GetX Controller dan Hive.

### 5. Profile Page (Bobot 10%)
- Menampilkan **Username** user yang diambil langsung dari **SharedPreferences** (`124240047`).
- Menampilkan kartu **Kesan dan Pesan** selama mengikuti praktikum pemrograman mobile.
- Tombol **Logout** yang fungsional dengan dialog konfirmasi, menghapus sesi SharedPreferences, dan mengarahkan kembali ke LoginPage.

### 6. Poin Tambahan: Implementasi GetX
- Menggunakan `GetMaterialApp` sebagai root widget.
- Menggunakan **GetX Navigation**: `Get.to()`, `Get.back()`, `Get.offAll()`.
- Menggunakan **GetX Snackbar**: notifikasi feedback saat login, toggle favorit, dan logout.
- Menggunakan **GetxController** (`FavoriteController`) dengan `RxList` dan `Obx` untuk pembaruan UI secara otomatis dan responsif.

---

## 📂 Struktur Proyek
```text
lib/
├── controllers/
│   └── favorite_controller.dart     # GetX Controller manajemen state favorit
├── models/
│   └── show_model.dart              # Model data TV Show & parsing JSON
├── services/
│   ├── api_service.dart             # Logika HTTP request TVMaze API (terpisah dari UI)
│   ├── favorite_service.dart        # Logika penyimpanan lokal Hive
│   └── pref_service.dart            # Logika SharedPreferences (sesi login)
├── views/
│   ├── detail_page.dart             # Halaman detail show (API /shows/{id})
│   ├── favorite_page.dart           # Halaman daftar show favorit (Hive)
│   ├── home_page.dart               # Halaman beranda daftar shows (Grid & API)
│   ├── login_page.dart              # Halaman login (NIM & password 123)
│   ├── main_navigation_page.dart    # BottomNavigationBar (Beranda, Favorit, Profil)
│   └── profile_page.dart            # Halaman profil user & kesan pesan
└── main.dart                        # Inisialisasi Hive, SharedPreferences, & GetMaterialApp
```

---

## 🚀 Panduan Menjalankan Aplikasi

1. **Clone repository:**
   ```bash
   git clone https://github.com/<username-kamu>/Latres_Mobile_124240047.git
   cd Latres_Mobile_124240047/responsi
   ```
2. **Install dependensi:**
   ```bash
   flutter pub get
   ```
3. **Jalankan aplikasi:**
   ```bash
   flutter run
   ```
   *(Pilih perangkat yang tersedia: Android Emulator, Chrome, atau Windows Desktop)*

4. **Kredensial Login:**
   - **Username:** `124240047`
   - **Password:** `123`
