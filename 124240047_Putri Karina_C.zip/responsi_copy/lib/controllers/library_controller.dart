import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:responsi/models/anime_model.dart';
import '../models/anime_model.dart';
import '../services/library_service.dart';

class LibraryController extends GetxController {
  final RxList<Anime> animes = <Anime>[].obs;

  @override
  void onInit() {
    super.onInit();
    loadAnimes();
  }

  void loadAnimes() {
    animes.assignAll(LibraryService.getAllAnimes());
  }

  
  bool isOwned(int id) {
    return animes.any((anime) => anime.id == id);
  }

  Future<void> toggleAnime(Anime anime) async {
    if (isOwned(anime.id)) {
      await LibraryService.removeAnime(anime.id);
      loadAnimes();
      Get.snackbar(
        'Library',
        '${anime.titles} dihapus dari library kamu.',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: const Color(0xFF282828),
        colorText: Colors.white,
        margin: const EdgeInsets.all(12),
        duration: const Duration(seconds: 2),
      );
    } else {
      await LibraryService.addAnime(anime);
      loadAnimes();
      Get.snackbar(
        'Berhasil!',
        '${anime.titles} berhasil ditambahkan ke library!',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: const Color(0xFF1E88E5),
        colorText: Colors.white,
        margin: const EdgeInsets.all(12),
        duration: const Duration(seconds: 2),
      );
    }
  }

  Future<void> removeAnime(int id, String title) async {
    await LibraryService.removeAnime(id);
    loadAnimes();
    Get.snackbar(
      'Dihapus',
      '$title telah dihapus dari library.',
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: const Color(0xFF282828),
      colorText: Colors.white,
      margin: const EdgeInsets.all(12),
      duration: const Duration(seconds: 2),
    );
  }
}
