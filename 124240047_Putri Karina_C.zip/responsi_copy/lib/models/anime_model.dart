import 'package:flutter/foundation.dart';

// =============================================================================
// 📦 PANDUAN LENGKAP: CARA MENGAMBIL DATA NESTED (BERSARANG) DARI JSON API
// =============================================================================
//
// 🔹 TIPE 1: NESTED OBJEK / MAP (Kurung kurawal di dalam kurung kurawal { ... { ... } })
//    Contoh bentuk JSON API:
//    {
//      "name": "Under the Dome",
//      "image": {
//        "original": "https://.../poster.jpg"
//      },
//      "rating": {
//        "average": 8.5
//      }
//    }
//    👉 CARA AMBIL DI DART (Panggil dua kurung siku berjenjang pakai tanda tanya '?'):
//       imageUrl: json['image']?['original'] as String? ?? '',
//       rating: (json['rating']?['average'] as num?)?.toDouble() ?? 0.0,
//       (Catatan: Tanda '?' sangat penting agar tidak crash jika 'image' bernilai null!)
//
// 🔹 TIPE 2: NESTED LIST OF MAP (Kurung kurawal di dalam kurung siku [ { ... }, { ... } ])
//    Contoh bentuk JSON API:
//    {
//      "title": "Overwatch",
//      "screenshots": [
//        { "id": 1, "image": "https://.../foto1.jpg" },
//        { "id": 2, "image": "https://.../foto2.jpg" }
//      ]
//    }
//    👉 CARA AMBIL DI DART (Bongkar kotaknya satu per satu pakai perulangan 'for'):
//       List<String> screenList = [];
//       if (json['screenshots'] != null && json['screenshots'] is List) {
//         for (var item in json['screenshots']) {
//           if (item is Map && item['image'] != null) {
//             screenList.add(item['image'].toString());
//           }
//         }
//       }
//
// 🔹 TIPE 3: LIST TEKS BIASA / BUKAN NESTED (Cuma kumpulan kata: ["Action", "Drama"])
//    Contoh bentuk JSON API:
//    {
//      "genres": ["Action", "Drama", "Sci-Fi"]
//    }
//    👉 CARA AMBIL DI DART (Cukup 1 baris saja):
//       genres: json['genres'] != null ? List<String>.from(json['genres']) : [],
// =============================================================================

// 🌐 Helper otomatis: jika dijalankan di Chrome Web, gambar di-bypass via proxy
// agar tidak terblokir oleh aturan CORS browser Chrome. Di Android/HP tetap pakai URL asli.

class Anime {
  final int id;
  final String titles;
  final String averageRating;
  final String? description;
  final String? synopsis;
  final String ageRating;
  final String? imageUrl;
  final String tinyPosterImage;
  final String? episodeCount;

  Anime({
    required this.id,
    required this.titles,
    required this.averageRating,
    required this.description,
    this.synopsis,
    required this.ageRating,
    this.imageUrl,
    required this.tinyPosterImage,
    this.episodeCount,
  });

  factory Anime.fromJson(Map<String, dynamic> json) {
    return Anime(
      id: json['id'] as int,
      titles: json['titles'] != null ? json['titles']['en_jp'] as String? ?? '': '',
      averageRating: json['averageRating'] as String? ?? '0.0',
      description: json['description'] as String?,
      synopsis: json['synopsis'] as String?,
      ageRating: json['ageRating'] as String? ?? 'General',
      imageUrl: json['posterImage'] != null ? json['posterImage']['medium'] as String? : null,
      tinyPosterImage: json['posterImage'] != null ? json['posterImage']['tiny'] as String? ?? '': '',
      episodeCount: json['episodeCount'] as String?,
    );
  }


  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'titles': titles,
      'averageRating': averageRating,
      'description': description,
      'synopsis': synopsis,
      'ageRating': ageRating,
      'tinyPosterImage': tinyPosterImage,
      'episodeCount': episodeCount,
    };
  }

  factory Anime.fromMap(Map<dynamic, dynamic> map) {
    return Anime(
      id: map['id'] as int,
      titles: map['titles'] as String? ?? 'Untitled',
      averageRating: map['averageRating'] as String? ?? '0.0',
      description: map['description'] as String?,
      synopsis: map['synopsis'] as String?,
      ageRating: map['ageRating'] as String? ?? 'General',
      tinyPosterImage: map['tinyPosterImage'] as String? ?? '',
      episodeCount: map['episodeCount'] as String?,
    );
  }
}
