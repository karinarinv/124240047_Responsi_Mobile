import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'controllers/library_controller.dart';
import 'services/library_service.dart';
import 'services/pref_service.dart';
import 'views/login_page.dart';
import 'views/main_navigation_page.dart';

void main() async {
  // 1. Pastikan binding flutter aktif sebelum async operation
  WidgetsFlutterBinding.ensureInitialized();

  // 2. Inisialisasi Database Hive lokal & buka box
  await Hive.initFlutter();
  await Hive.openBox(LibraryService.boxName);

  // 3. Daftarkan Controller GetX ke dependency injection
  Get.put(LibraryController());

  // 4. Cek apakah user sudah pernah login sebelumnya di SharedPreferences
  final bool isLoggedIn = await PrefService.isLoggedIn();

  runApp(MyApp(isLoggedIn: isLoggedIn));
}

class MyApp extends StatelessWidget {
  final bool isLoggedIn;

  const MyApp({super.key, required this.isLoggedIn});

  @override
  Widget build(BuildContext context) {
    // =========================================================================
    // 🎨 [GANTI WARNA TEMA GLOBAL APLIKASI]:
    // Ganti Color(0xFF1E88E5) dengan warna yang diminta asisten praktikum:
    // - Biru:   Color(0xFF1E88E5)
    // - Merah:  Color(0xFFE50914)
    // - Hijau:  Color(0xFF4CAF50)
    // - Orange: Color(0xFFFF9800)
    // =========================================================================
    const Color appPrimaryColor = Color(0xFF1E88E5);

    return GetMaterialApp(
      // 👈 [GANTI BRAND]: sesuaikan nama aplikasi jika tema/API ujian berbeda.
      title: 'Hydra Games',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF121212), // 🎨 Warna background layar
        primaryColor: appPrimaryColor,
        colorScheme: const ColorScheme.dark(
          primary: appPrimaryColor,
          surface: Color(0xFF1E1E1E), // 🎨 Warna background kartu
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF121212),
          elevation: 0,
        ),
      ),
      // Jika sudah login buka MainNavigationPage, jika belum buka LoginPage
      home: isLoggedIn ? const MainNavigationPage() : const LoginPage(),
      
      //cek sharepreference klo gk dipake
      // home: const LoginPage(),
    );
  }
}
