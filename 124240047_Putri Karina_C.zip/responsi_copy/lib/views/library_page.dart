import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/library_controller.dart';
import 'detail_page.dart';

class LibraryPage extends StatelessWidget {
  const LibraryPage({super.key});

  @override
  Widget build(BuildContext context) {
    final LibraryController controller = Get.find<LibraryController>();

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        title: const Text(
          'Library Anda',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 20),
        ),
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: false,
      ),
      body: Obx(() {
        final list = controller.animes.toList();

        if (list.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.sports_esports_outlined, size: 64, color: Colors.grey.shade600),
                const SizedBox(height: 16),
                Text(
                  'Library Anda masih kosong.',
                  style: TextStyle(color: Colors.grey.shade400, fontSize: 16),
                ),
                const SizedBox(height: 6),
                Text(
                  'Dapatkan anime dari halaman Browse atau Detail!',
                  style: TextStyle(color: Colors.grey.shade600, fontSize: 13),
                ),
              ],
            ),
          );
        }

        // 👈 [SESUAIKAN MODEL API]: list ini berisi Game; sesuaikan tipe/field jika model diganti.
        return ListView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          itemCount: list.length,
          itemBuilder: (context, index) {
            final anime = list[index];

            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                color: const Color(0xFF1E1E1E),
                borderRadius: BorderRadius.circular(10),
              ),
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                // 👈 [SESUAIKAN ID]: game.id dan parameter gameId harus mengikuti ID dari API baru.
                onTap: () {
                  Get.to(() => DetailPage(animeId: anime.id))?.then((_) {
                    controller.loadAnimes();
                  });
                },
                leading: ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: anime.tinyPosterImage.isNotEmpty
                      ? Image.network(
                          anime.tinyPosterImage,
                          width: 65,
                          height: 50,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) => Container(
                            width: 65,
                            height: 50,
                            color: const Color(0xFF282828),
                            child: const Icon(Icons.broken_image, color: Colors.grey),
                          ),
                        )
                      : Container(
                          width: 65,
                          height: 50,
                          color: const Color(0xFF282828),
                          child: const Icon(Icons.videogame_asset, color: Colors.grey),
                        ),
                ),
                title: Text(
                  anime.titles,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: const Color(0xFF2A2A2A),
                        borderRadius: BorderRadius.circular(4),
                      ),
                    )
                  ],
                ),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_rounded, color: Colors.red),
                  onPressed: () {
                    controller.removeAnime(anime.id, anime.titles);
                  },
                ),
              ),
            );
          },
        );
      }),
    );
  }
}
