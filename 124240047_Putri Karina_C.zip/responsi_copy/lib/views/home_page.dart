import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../models/anime_model.dart';
import '../services/api_service.dart';
import 'detail_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Anime> _allAnimes = []; // Menyimpan data asli lengkap dari API
  List<Anime> _filteredAnimes =
      []; // Menyimpan data yang sedang ditampilkan (hasil search)
  bool _isLoading = true; // Status loading indicator
  String? _errorMessage; // Status pesan error jika API gagal
  final TextEditingController _searchController = TextEditingController();
  final Color themeColor = const Color(0xFF1E88E5);

  @override
  void initState() {
    super.initState();
    _fetchAnimes();
  }

  void _fetchAnimes() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final animes = await ApiService.fetchAnimes();
      setState(() {
        _allAnimes = animes;
        _filteredAnimes = animes;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
        _isLoading = false;
      });
    }
  }

  void _filterAnimes(String query) {
    setState(() {
      if (query.trim().isEmpty) {
        _filteredAnimes = _allAnimes;
      } else {
        _filteredAnimes = _allAnimes.where((anime) {
          return anime.titles.toLowerCase().contains(query.toLowerCase()) ||
              anime.titles.toLowerCase().contains(query.toLowerCase());
        }).toList();
      }
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Widget _buildMetaColumn(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(color: Colors.grey.shade400, fontSize: 11),
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        title: const Text(
          'Keripikroll', // 🎨 Judul AppBar Home
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
            fontSize: 20,
          ),
        ),
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        centerTitle: false,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 16.0,
              vertical: 8.0,
            ),
            child: TextField(
              controller: _searchController,
              onChanged: _filterAnimes,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Cari nama anime',
                hintStyle: TextStyle(color: Colors.grey.shade500, fontSize: 14),
                prefixIcon: const Icon(Icons.search, color: Colors.grey),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(
                          Icons.clear,
                          color: Colors.grey,
                          size: 20,
                        ),
                        onPressed: () {
                          _searchController.clear();
                          _filterAnimes('');
                        },
                      )
                    : null,
                filled: true,
                fillColor: const Color(0xFF1E1E1E),
                contentPadding: const EdgeInsets.symmetric(vertical: 12),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none,
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: themeColor, width: 1.2),
                ),
              ),
            ),
          ),
          // ===================================================================
          // ✂️ [BATAS AKHIR SEARCH BAR]
          // ===================================================================

          // Konten ListView Game
          Expanded(
            child: RefreshIndicator(
              color: themeColor,
              backgroundColor: const Color(0xFF1E1E1E),
              onRefresh: () async => _fetchAnimes(),
              child: _buildContent(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContent() {
    // -------------------------------------------------------------------------
    // 📍 1. LOADING INDICATOR (Kriteria Wajib Soal 2.c)
    // -------------------------------------------------------------------------
    if (_isLoading) {
      return Center(child: CircularProgressIndicator(color: themeColor));
    }

    // -------------------------------------------------------------------------
    // 📍 2. ERROR STATE (Jika API gagal di-load)
    // -------------------------------------------------------------------------
    if (_errorMessage != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, size: 48, color: Colors.red),
              const SizedBox(height: 12),
              Text(
                'Gagal memuat game:\n$_errorMessage',
                style: TextStyle(color: Colors.grey.shade300, fontSize: 14),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: themeColor),
                onPressed: _fetchAnimes,
                child: const Text(
                  'Coba Lagi',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (_filteredAnimes.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.search_off_rounded,
              size: 56,
              color: Colors.grey.shade600,
            ),
            const SizedBox(height: 12),
            Text(
              'Anime "${_searchController.text}" tidak ditemukan.',
              style: TextStyle(color: Colors.grey.shade400, fontSize: 15),
            ),
          ],
        ),
      );
    }

    return GridView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, // 💡 Menampilkan 2 kolom per baris
        childAspectRatio: 0.78, // Rasio tinggi-lebar kartu
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: _filteredAnimes.length,
      itemBuilder: (context, index) {
        final anime = _filteredAnimes[index];

        return GestureDetector(
          onTap: () {
            // 👈 [SESUAIKAN ID]: samakan anime.id dan parameter DetailPage dengan ID API baru.
            Get.to(() => DetailPage(animeId: anime.id));
          },
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.3),
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            clipBehavior: Clip.antiAlias,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 👈 [SESUAIKAN FIELD GAMBAR]: game.thumbnail -> field gambar model baru.
                Expanded(
                  child: anime.tinyPosterImage.isNotEmpty
                      ? Image.network(
                          anime.tinyPosterImage,
                          width: double.infinity,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) =>
                              Container(
                                color: const Color(0xFF282828),
                                child: const Center(
                                  child: Icon(
                                    Icons.broken_image,
                                    color: Colors.grey,
                                  ),
                                ),
                              ),
                        )
                      : Container(
                          color: const Color(0xFF282828),
                          child: const Center(
                            child: Icon(
                              Icons.videogame_asset,
                              color: Colors.grey,
                            ),
                          ),
                        ),
                ),
                // 👈 [SESUAIKAN FIELD MODEL]: title, genre, dan platform harus cocok dengan model API baru.
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        anime.titles,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 3),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _buildMetaColumn(
                            'ageRating',
                            anime.ageRating ?? 'N/A',
                          ),
                          _buildMetaColumn(
                            'episodeCount',
                            anime.episodeCount ?? 'N/A',
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),

                      Row(
                        children: [
                          const Icon(
                            Icons.star_rounded,
                            color: Color(0xFFFFC107),
                            size: 22,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            double.tryParse(anime.averageRating ?? '')
                                    ?.toStringAsFixed(1) ??
                                'N/A',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
