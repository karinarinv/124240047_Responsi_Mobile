import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:responsi/models/anime_model.dart';
import '../controllers/library_controller.dart';
import '../services/api_service.dart';

class DetailPage extends StatefulWidget {
  final int animeId;

  const DetailPage({super.key, required this.animeId});

  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  late Future<Anime> _animeFuture;
  final LibraryController _libraryController = Get.find<LibraryController>();
  bool _hasPlayed = false; 
  final Color themeColor = const Color(0xFF1E88E5);
  @override
  void initState() {
    super.initState();
    _animeFuture = ApiService.fetchAnimeDetail(widget.animeId);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        title: const Text(
          'Detail',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 18),
        ),
        backgroundColor: const Color(0xFF121212),
        elevation: 0,
        // b. User dapat kembali ke Home dari Detail Page
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Get.back(),
        ),
      ),
      // c. Ada loading indicator untuk saat load data game
      // 👈 [GANTI INI JADI]: body: FutureBuilder<[NamaModelBaru]>(
      body: FutureBuilder<Anime>(
        future: _animeFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator(color: themeColor));
          }

          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.error_outline, size: 48, color: Colors.red),
                    const SizedBox(height: 12),
                    Text(
                      'Gagal memuat detail game:\n${snapshot.error}',
                      style: TextStyle(color: Colors.grey.shade300),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: themeColor),
                      onPressed: () {
                        setState(() {
                          _animeFuture = ApiService.fetchAnimeDetail(widget.animeId);
                        });
                      },
                      child: const Text('Coba Lagi', style: TextStyle(color: Colors.white)),
                    ),
                  ],
                ),
              ),
            );
          }

          final anime = snapshot.data;
          if (anime == null) {
            return const Center(child: Text('Data anime tidak ditemukan', style: TextStyle(color: Colors.white)));
          }

          final poster = anime.tinyPosterImage ?? anime.imageUrl;
          final title = anime.titles ?? anime.titles ?? 'Untitled';


          return SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
               if (poster != null)
                  Image.network(
                    poster,
                    width: double.infinity,
                    height: 380,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) => Container(
                      height: 250,
                      color: const Color(0xFF1E1E1E),
                      child: const Center(
                        child: Icon(Icons.broken_image, size: 60, color: Colors.grey),
                      ),
                    ),
                  )
                else
                  Container(
                    height: 250,
                    color: const Color(0xFF1E1E1E),
                    child: const Center(
                      child: Icon(Icons.movie, size: 60, color: Colors.grey),
                    ),
                  ),


                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        anime.titles,
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 12),

                        Row(
                        children: [
                          const Icon(Icons.star_rounded, color: Color(0xFFFFC107), size: 22),
                          const SizedBox(width: 6),
                          Text(
                            double.tryParse(anime.averageRating ?? '')?.toStringAsFixed(1) ?? 'N/A',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                         
                        ],
                      ),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _buildMetaColumn('ageRating', anime.ageRating ?? 'N/A'),
                          _buildMetaColumn('episodeCount', anime.episodeCount ?? 'N/A'),
                        ],
                      ),
                      const SizedBox(height: 20),

                      Row(
                        children: [
                          // 1. Tombol 'Mainkan' (Hanya mengubah teks/status sedang dimainkan)
                          Expanded(
                            child: SizedBox(
                              height: 48,
                              child: ElevatedButton.icon(
                                onPressed: () {
                                  setState(() => _hasPlayed = !_hasPlayed);
                                  Get.snackbar(
                                    _hasPlayed ? 'Sedang Dimainkan' : 'Selesai',
                                    _hasPlayed ? 'Selamat bermain ${anime.titles}!' : 'Kamu berhenti bermain.',
                                    snackPosition: SnackPosition.BOTTOM,
                                    backgroundColor: _hasPlayed ? const Color(0xFF1E2D24) : const Color(0xFF282828),
                                    colorText: Colors.white,
                                    margin: const EdgeInsets.all(12),
                                    duration: const Duration(seconds: 2),
                                  );
                                },
                                icon: Icon(
                                  _hasPlayed ? Icons.check_circle_rounded : Icons.play_arrow_rounded,
                                  color: _hasPlayed ? const Color(0xFF4CAF50) : Colors.white,
                                ),
                                label: Text(
                                  _hasPlayed ? 'Sedang Dimainkan' : 'Mainkan',
                                  style: TextStyle(
                                    color: _hasPlayed ? const Color(0xFF4CAF50) : Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                  ),
                                ),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: _hasPlayed ? const Color(0xFF1E2D24) : themeColor,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                    side: BorderSide(
                                      color: _hasPlayed ? const Color(0xFF4CAF50) : Colors.transparent,
                                      width: 1.2,
                                    ),
                                  ),
                                  elevation: _hasPlayed ? 0 : 3,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),

                          // 2. Tombol Love / Favorit (YANG MENYIMPAN KE DATABASE HIVE)
                          Obx(() {
                            final isOwned = _libraryController.animes.any((a) => a.id == anime.id);
                            return Container(
                              height: 48,
                              width: 48,
                              decoration: BoxDecoration(
                                color: const Color(0xFF1E1E1E),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: isOwned ? Colors.red : Colors.grey.shade700,
                                  width: 1.2,
                                ),
                              ),
                              child: IconButton(
                                icon: Icon(
                                  isOwned ? Icons.favorite : Icons.favorite_border,
                                  color: isOwned ? Colors.red : Colors.white,
                                  size: 22,
                                ),
                                onPressed: () {
                                  _libraryController.toggleAnime(anime);
                                },
                              ),
                            );
                          }),
                        ],
                      ),

                      const SizedBox(height: 24),

                      const Text(
                        'Overview',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        (anime.description != null && anime.description!.isNotEmpty)
                            ? anime.description!
                            : (anime.synopsis ?? 'Tidak ada deskripsi tersedia.'),
                        style: TextStyle(
                          color: Colors.grey.shade300,
                          fontSize: 14,
                          height: 1.5,
                        ),
                      ),
                      // =========================================================================
                      // ❗ [BATAS AKHIR DESKRIPSI SAMPAI SINI]
                      // =========================================================================

                      const SizedBox(height: 30),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildMetaColumn(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: Colors.grey, fontSize: 11)),
        const SizedBox(height: 3),
        SizedBox(
          width: 105,
          child: Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600),
          ),
        ),
      ],
    );
  }
}
