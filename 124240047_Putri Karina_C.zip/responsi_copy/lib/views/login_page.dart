import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../services/pref_service.dart';
import 'main_navigation_page.dart';


class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  bool _obscurePassword = true;
  bool _isLoading = false;

  static const String validUsername = '124240047';
  static const String validPassword = '123';

  final Color primaryColor = const Color(0xFF1E88E5);

  void _handleLogin() async {
    if (!_formKey.currentState!.validate()) return;

    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    setState(() => _isLoading = true);
    await Future.delayed(const Duration(milliseconds: 300));

    setState(() => _isLoading = false);
    if (email == validUsername && password == validPassword) {
      await PrefService.saveLoginSession(email);
      Get.offAll(() => const MainNavigationPage());
      Get.snackbar(
        'Login Berhasil',
        'Selamat datang kembali, $email!',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: primaryColor,
        colorText: Colors.white,
        margin: const EdgeInsets.all(12),
        duration: const Duration(seconds: 2),
      );
    } else {
      Get.snackbar(
        'Login Gagal',
        'Username (NIM) atau Password salah!\nNIM: $validUsername, Password: $validPassword',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red.shade800,
        colorText: Colors.white,
        margin: const EdgeInsets.all(12),
        duration: const Duration(seconds: 3),
      );
    }
    return;
  }
  

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 28.0),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [

                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: primaryColor.withValues(alpha: 0.15),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.sports_esports_rounded, // 🎨 Ganti ikon logo di sini
                      size: 64,
                      color: primaryColor,
                    ),
                  ),

                  /*
                  // -----------------------------------------------------------
                  // [OPSI 2 - DARI INTERNET]: Ganti Icon Jadi Foto dari URL (Paling cepat saat ujian!)
                  // Cukup un-comment (hapus /* dan */) blok ini dan jadikan komentar Opsi 1 di atas.
                  // -----------------------------------------------------------
                  ClipRRect(
                    borderRadius: BorderRadius.circular(50), // 50 = Bentuk lingkaran
                    child: Image.network(
                      'https://picsum.photos/200', // 🌐 Ganti dengan link URL foto online
                      width: 90,
                      height: 90,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) => Icon(
                        Icons.broken_image,
                        size: 64,
                        color: primaryColor,
                      ),
                    ),
                  ),
                  */

                  /*
                  // -----------------------------------------------------------
                  // [OPSI 3 - DARI ASSETS LOKAL]: Ganti Icon Jadi Foto dari Folder Laptop
                  // Syarat: daftarkan path gambar di pubspec.yaml terlebih dahulu
                  // -----------------------------------------------------------
                  ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: Image.asset(
                      'assets/logo.png', // 📁 Path gambar di folder project
                      width: 90,
                      height: 90,
                      fit: BoxFit.cover,
                    ),
                  ),
                  */
                  const SizedBox(height: 18),

                  // 👈 [GANTI BRAND]: sesuaikan nama aplikasi jika tema/API ujian berbeda.
                  const Text(
                    'Keripikroll',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 36),

                  // ===========================================================
                  // 📍 INPUT 1: EMAIL (Atau Username / NIM)
                  // ===========================================================
                  TextFormField(
                    controller: _emailController,
                    keyboardType: TextInputType.emailAddress,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: 'Username', // 💡 Ubah jadi 'Username (NIM)' jika diminta NIM
                      hintStyle: TextStyle(color: Colors.grey.shade500),
                      prefixIcon: const Icon(Icons.email_outlined, color: Colors.grey),
                      filled: true,
                      fillColor: const Color(0xFF1E1E1E),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide.none,
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: primaryColor, width: 1.5),
                      ),
                      contentPadding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                    // ---------------------------------------------------------
                    // 🔍 VALIDASI INPUT USERNAME / EMAIL:
                    // ---------------------------------------------------------
                    validator: (val) {
                      if (val == null || val.trim().isEmpty) {
                        return 'Username tidak boleh kosong';
                      }

                      return null;
                    },
                  ),
                  const SizedBox(height: 16),

                  // ===========================================================
                  // 📍 INPUT 2: PASSWORD
                  // ===========================================================
                  TextFormField(
                    controller: _passwordController,
                    obscureText: _obscurePassword,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: 'Password',
                      hintStyle: TextStyle(color: Colors.grey.shade500),
                      prefixIcon: const Icon(Icons.lock_outline, color: Colors.grey),
                      suffixIcon: IconButton(
                        icon: Icon(
                          _obscurePassword ? Icons.visibility_off : Icons.visibility,
                          color: Colors.grey,
                        ),
                        onPressed: () {
                          setState(() => _obscurePassword = !_obscurePassword);
                        },
                      ),
                      filled: true,
                      fillColor: const Color(0xFF1E1E1E),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide.none,
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: primaryColor, width: 1.5),
                      ),
                      contentPadding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                    validator: (val) {
                      if (val == null || val.trim().isEmpty) return 'Password wajib diisi';
                      return null;
                    },
                  ),
                  const SizedBox(height: 28),

                  // ===========================================================
                  // 📍 TOMBOL LOGIN
                  // ===========================================================
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _isLoading ? null : _handleLogin,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: primaryColor, // 🎨 Warna tombol Login
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        elevation: 3,
                      ),
                      child: _isLoading
                          ? const SizedBox(
                              width: 22,
                              height: 22,
                              child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5),
                            )
                          : const Text(
                              'Login',
                              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                            ),
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
