import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/anime_model.dart';

class ApiService {
  static const String baseUrl = 'https://kitsu.io/api/edge/anime';

  static Future<List<Anime>> fetchAnimes() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/anime'));

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        return data.map((item) => Anime.fromJson(item)).toList();
      } else {
        throw Exception(
          'Gagal memuat data dari server (${response.statusCode})',
        );
      }
    } catch (e) {
      throw Exception('Koneksi internet bermasalah atau URL API salah: $e');
    }
  }

  static Future<Anime> fetchAnimeDetail(int id) async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/anime/$id'));

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);

        return Anime.fromJson(data);
      } else {
        throw Exception('Gagal memuat detail (${response.statusCode})');
      }
    } catch (e) {
      throw Exception('Terjadi kesalahan memuat detail: $e');
    }
  }
}
