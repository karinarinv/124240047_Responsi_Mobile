import 'package:hive_flutter/hive_flutter.dart';
import 'package:responsi/models/anime_model.dart';


class LibraryService {
  static const String boxName = 'Keripikroll_animes_library';

  static Box get _box => Hive.box(boxName);

  static Future<void> addAnime(Anime anime) async {
    await _box.put(anime.id.toString(), anime.toMap());
  }

  static Future<void> removeAnime(int id) async {
    await _box.delete(id.toString());
  }

  static bool isAnimeInLibrary(int id) {
    return _box.containsKey(id.toString());
  }

  static List<Anime> getAllAnimes() {
    final List<Anime> list = [];
    for (var i = 0; i < _box.length; i++) {
      final data = _box.getAt(i);
      if (data != null && data is Map) {
        list.add(Anime.fromMap(data));
      }
    }
    return list;
  }

  static int getAnimesCount() {
    return _box.length;
  }
}
