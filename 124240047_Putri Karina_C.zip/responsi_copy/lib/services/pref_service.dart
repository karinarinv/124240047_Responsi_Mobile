import 'package:shared_preferences/shared_preferences.dart';

class PrefService {
  static const String _keyIsLoggedIn = 'is_logged_in';
  static const String _keyEmail = 'user_email';

  // ✂️ [BATAS AWAL HAPUS KEY REGISTRASI]
  // Menyimpan data akun saat user melakukan registrasi
  static const String _keyRegisteredEmail = 'registered_email';
  static const String _keyRegisteredPassword = 'registered_password';
  // ✂️ [BATAS AKHIR HAPUS KEY REGISTRASI]

  // ✂️ [BATAS AWAL HAPUS FUNGSI REGISTRASI]
  /// 1. Simpan data registrasi ke SharedPreferences
  static Future<void> registerUser({
    required String email,
    required String password,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyRegisteredEmail, email.trim());
    await prefs.setString(_keyRegisteredPassword, password.trim());
  }
  // ✂️ [BATAS AKHIR HAPUS FUNGSI REGISTRASI]

  /// 2. Validasi Login yang KETAT & BENAR:
  /// Password dan Email WAJIB COCOK. Jika salah, DITOLAK!
  static Future<bool> validateLogin(String email, String password) async {
    final inputEmail = email.trim().toLowerCase();
    final inputPassword = password.trim();

    // ✂️ [BATAS AWAL HAPUS CEK AKUN TERDAFTAR]
    final prefs = await SharedPreferences.getInstance();
    final regEmail = prefs.getString(_keyRegisteredEmail);
    final regPassword = prefs.getString(_keyRegisteredPassword);

    // A. Cek apakah cocok dengan Akun yang baru didaftarkan di RegisterPage
    if (regEmail != null && regPassword != null) {
      if (inputEmail == regEmail.toLowerCase() && inputPassword == regPassword) {
        await saveLoginSession(regEmail);
        return true;
      }
    }
    // ✂️ [BATAS AKHIR HAPUS CEK AKUN TERDAFTAR]

    // B. Cek apakah cocok dengan Akun Default Pengujian (NIM 124240047 / admin)
    // Password default adalah '123'
    if ((inputEmail == '124240047') && inputPassword == '123') {
      await saveLoginSession(email.trim());
      return true;
    }

    // C. Jika tidak cocok sama sekali -> GAGAL LOGIN!
    return false;
  }

  /// 3. Simpan sesi login aktif ke SharedPreferences
  static Future<void> saveLoginSession(String email) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyIsLoggedIn, true);
    await prefs.setString(_keyEmail, email);
  }

  /// 4. Cek apakah user sedang dalam sesi login
  static Future<bool> isLoggedIn() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_keyIsLoggedIn) ?? false;
  }

  /// 5. Ambil email user untuk Profile Page
  static Future<String> getEmail() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyEmail) ?? 'karina@gmail.com';
  }

  /// 6. Logout: hapus sesi login aktif dari SharedPreferences
  static Future<void> clearSession() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyIsLoggedIn);
    await prefs.remove(_keyEmail);
  }
}
